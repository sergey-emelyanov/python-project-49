from brain_games.games.progression_game
from brain_games.launch import launch

def main():
	launch(progression_game)



if __name__ == "__main__":
	main()
